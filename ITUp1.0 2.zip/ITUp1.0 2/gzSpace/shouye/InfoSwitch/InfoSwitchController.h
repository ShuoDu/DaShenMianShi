//
//  InfoSwitchController.h
//  gzSpace
//
//  Created by 杜硕 on 2018/9/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "BaseController.h"
#import "TwoBaseController.h"
@interface InfoSwitchController : BaseController

@end

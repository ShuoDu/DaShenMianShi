//
//  InfoSwitchController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "InfoSwitchController.h"
#import "RHFiltrateView.h"

@interface InfoSwitchController ()<RHFiltrateViewDelegate>
@property (nonatomic,strong)RHFiltrateView *filtrate;
@end

@implementation InfoSwitchController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"专业信息";
    [self test];
}

- (void)test {
    self.view.backgroundColor = NewViewBack;
    self.navigationItem.rightBarButtonItem.title = @"完成";
    self.filtrate = [[RHFiltrateView alloc] initWithTitles:@[@"技能", @"等级", @"经验", @"岗位", @"目标薪资"] items:@[@[@"Ios",@"Java",@"PhP",@"Python",@"前端",@"测试",@"Android"], @[@"全部", @"初级",@"中级",@"高级"],  @[@"全部",@"应届",@"一年以内",@"1-3年",@"3-5年",@"5-10年",@"10年以上"],@[@"全部",@"开发",@"测试",@"运维",@"经理",@"总监"], @[@"全部", @"0-1000",@"1000-10000",@"1w-5w",@"5w-10w",@"10w+"]]];
    self.filtrate.frame = CGRectMake(0, 2, self.view.frame.size.width, self.view.frame.size.height);
    self.filtrate.delegate = self;
    [self.view addSubview: self.filtrate];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

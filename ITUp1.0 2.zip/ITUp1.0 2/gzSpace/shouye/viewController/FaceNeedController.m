//
//  FaceNeedController.m
//  gzSpace
//
//  Created by PAAT on 2018/11/24.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "FaceNeedController.h"

@interface FaceNeedController ()

@end

@implementation FaceNeedController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"面试须知";
}

@end

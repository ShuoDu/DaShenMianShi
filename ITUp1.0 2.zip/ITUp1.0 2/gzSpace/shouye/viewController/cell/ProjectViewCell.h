//
//  ProjectViewCell.h
//  gzSpace
//
//  Created by PAAT on 2018/11/7.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProjectViewCell : UICollectionViewCell

@end

NS_ASSUME_NONNULL_END

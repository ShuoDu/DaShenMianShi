//
//  ProjectViewCell.m
//  gzSpace
//
//  Created by PAAT on 2018/11/7.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "ProjectViewCell.h"

@implementation ProjectViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end

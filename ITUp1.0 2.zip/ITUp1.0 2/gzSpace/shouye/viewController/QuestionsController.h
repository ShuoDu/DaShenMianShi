//
//  QuestionsController.h
//  gzSpace
//
//  Created by PAAT on 2018/11/24.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "BaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QuestionsController : BaseController

@end

NS_ASSUME_NONNULL_END

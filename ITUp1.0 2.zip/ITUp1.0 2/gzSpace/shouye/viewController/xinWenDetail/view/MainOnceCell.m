//
//  MainOneCell.m
//  Iknow
//
//  Created by 杜硕 on 2018/8/31.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MainOnceCell.h"
@interface MainOnceCell()
@property (weak, nonatomic) IBOutlet UILabel *titile;

@end
@implementation MainOnceCell


-(CGFloat)stringHeightWithWidth:(int)width ForFont:(UIFont *)font string:(NSString *)string

{
    return [string boundingRectWithSize:CGSizeMake(width, 10000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil].size.height;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    CGFloat height = [self stringHeightWithWidth:self.titile.frame.size.width ForFont:[UIFont systemFontOfSize:17] string:self.titile.text] + 20;
    self.titile.frame = CGRectMake(15, 10, WIDTH-30, height);
    self.titile.font = [UIFont systemFontOfSize:17];
    //设置自动行数与字符换行
    [self.titile setNumberOfLines:0];
    self.titile.lineBreakMode = NSLineBreakByWordWrapping;

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

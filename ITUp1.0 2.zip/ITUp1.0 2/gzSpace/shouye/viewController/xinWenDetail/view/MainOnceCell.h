//
//  MainOneCell.h
//  Iknow
//
//  Created by 杜硕 on 2018/8/31.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainOnceCell : UITableViewCell

@end

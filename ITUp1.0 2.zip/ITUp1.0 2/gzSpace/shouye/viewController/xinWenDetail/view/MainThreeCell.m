//
//  MainThreeCell.m
//  Iknow
//
//  Created by 杜硕 on 2018/8/31.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MainThreeCell.h"

@implementation MainThreeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

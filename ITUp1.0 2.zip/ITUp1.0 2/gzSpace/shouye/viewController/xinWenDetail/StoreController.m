//
//  StoreController.m
//  gzSpace
//
//  Created by 智享单车 on 2017/12/12.
//  Copyright © 2017年 智享单车. All rights reserved.
//

#import "StoreController.h"

#import<AVFoundation/AVFoundation.h>//语音解读
#import "MainTabCell.h"
#import "NBLScrollTabController.h"
#import "WYWebController.h"
#import "MainOnceCell.h"

#import "DetailController.h"

#import "MainOnceCell.h"
#import "MainTwoCell.h"
#import "MainThreeCell.h"
#import "MainFourCell.h"

static NSString *mainOne = @"MainOnceCell";
static NSString *mainTwo = @"MainTwoCell";
static NSString *mainThree = @"MainThreeCell";
static NSString *mainFour = @"MainFourCell";
@interface StoreController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *myTableView;
@property (nonatomic, strong) NSMutableArray *btnArray;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *viewControllers;
@property (nonatomic, strong) NSMutableArray *datasArray;
@property (nonatomic, strong) AVSpeechSynthesizer * synthsizer;
@end


@implementation StoreController

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [self.synthsizer pauseSpeakingAtBoundary:AVSpeechBoundaryImmediate];//暂停
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"科技头条";
    UIBarButtonItem *rig = [[UIBarButtonItem alloc]initWithTitle:@"语音收听" style:UIBarButtonItemStylePlain target:self action:@selector(yuYin)];
    rig.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = rig;
    [self addTableView];
//    [self loadData];
}

- (void)yuYin {
    NSLog(@"播放了");
    self.synthsizer = [[AVSpeechSynthesizer alloc] init];
    NSArray * verses = @[
                         @"ios12有哪些功能,下面为你一一解读,首先屏幕分辨率比较高",
                         @"陌上花开,可缓缓归矣",
                         @"沾衣欲湿杏花雨，吹面不寒杨柳风",
                         @"竹外桃花三两枝，春江水暖鸭先知",
                         @"几处早莺争暖树,谁家新燕啄春泥",
                         @"乱花渐欲迷人眼,浅草才能没马蹄"
                         ];
    for (int i = 0; i < verses.count; i++) {
        AVSpeechUtterance *utterance = [[AVSpeechUtterance alloc]initWithString:verses[i]];
        utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-CN"];
        utterance.rate = 0.4;
        utterance.pitchMultiplier = 0.8;
        utterance.postUtteranceDelay = 0.1;
        [self.synthsizer speakUtterance:utterance];//播放
        // [self.synthsizer pauseSpeakingAtBoundary:AVSpeechBoundaryImmediate];//暂停
        // [self.synthsizer continueSpeaking];//继续
    }
}

- (void) addTableView {
    self.myTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-20) style:UITableViewStylePlain];
    self.myTableView.delegate = self;
    self.myTableView.dataSource = self;
//    self.myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.myTableView.backgroundColor = NewViewBack;
    
    [self.myTableView registerNib:[UINib nibWithNibName:@"MainOnceCell" bundle:nil] forCellReuseIdentifier:mainOne];
    [self.myTableView registerNib:[UINib nibWithNibName:@"MainTwoCell" bundle:nil] forCellReuseIdentifier:mainTwo];
    [self.myTableView registerNib:[UINib nibWithNibName:@"MainThreeCell" bundle:nil] forCellReuseIdentifier:mainThree];
    [self.myTableView registerNib:[UINib nibWithNibName:@"MainFourCell" bundle:nil] forCellReuseIdentifier:mainThree];
    
    //1 去除掉自动布局添加的边距
    self.myTableView.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
    //2 去掉iOS7的separatorInset边距
    self.myTableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
   
    [self.view addSubview:self.myTableView];
}


- (void)loadData {
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"sucai/all/"];
    [CYXHttpRequest get:urls params:nil success:^(id responseObj) {
        NSMutableArray *dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableLeaves error:nil];
        [self.dataArray removeAllObjects];
        self.dataArray=[NSMutableArray array];
        for (NSDictionary *dict in dataArray) {
//            MainMessageModel *messageModel = [MainMessageModel yy_modelWithDictionary:dict];
//            [self.dataArray addObject:messageModel];
        }
        [self.myTableView reloadData];
    } failure:^(NSError *error) {
    }];
}

#pragma mark - UITableViewDelaget
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    return self.dataArray.count;
    return 10;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (indexPath.row == 0) {
//        return 178;
//    }else if (indexPath.row ==1) {
//        return 96;
//    }else if (indexPath.row ==2) {
//        return 220;
//    }
//    return 168;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 5;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, 5)];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 60;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0,WIDTH, 60)];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 168;
    }else if (indexPath.row ==1) {
        return 93;
    }
    return 168;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    MainMessageModel *model = self.dataArray[indexPath.row];
//    MainTabCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"MainTabCell"];
//    [cellOne loadData:model];
//    cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
//    cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
//    return cellOne;

//
    if (indexPath.row == 0) {
        MainOnceCell *cellOne = [tableView dequeueReusableCellWithIdentifier:mainOne];
        //    [cellOne loadData:model];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellOne;
    } else if (indexPath.row == 1) {
        MainTwoCell *cellTwo = [tableView dequeueReusableCellWithIdentifier:mainTwo];
        //    [cellOne loadData:model];
        cellTwo.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellTwo.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellTwo;
    }
     else {
        MainOnceCell *cellOne = [tableView dequeueReusableCellWithIdentifier:mainOne];
        //    [cellOne loadData:model];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellOne;
    }
    
//   else if (indexPath.row == 3) {
//        MainFourCell *cellFour = [tableView dequeueReusableCellWithIdentifier:mainFour];
//        cellFour.backgroundColor = [UIColor clearColor];
//        //    [cellOne loadData:model];
//        cellFour.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
//        cellFour.selectionStyle = UITableViewCellSelectionStyleNone;
//        return cellFour;
//    } else {
//        MainOnceCell *cellOne = [tableView dequeueReusableCellWithIdentifier:mainOne];
//        cellOne.backgroundColor = [UIColor clearColor];
//        //    [cellOne loadData:model];
//        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
//        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
//        return cellOne;
//    }
//    MainOnceCell *cellOne = [tableView dequeueReusableCellWithIdentifier:mainOne];
//    cellOne.backgroundColor = [UIColor whiteColor];
//    //    [cellOne loadData:model];
//    cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
//    cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
//    return cellOne;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"点我了");
//    MainMessageModel *model = self.dataArray[indexPath.row];
//    WYWebController *webVC = [WYWebController new];
//    webVC.url = model.message_url;
//    webVC.hidesBottomBarWhenPushed = YES;
//    [self.navigationController pushViewController:webVC animated:YES];
    
    DetailController *mes = [[DetailController alloc]init];
    mes.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:mes animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}



@end

//
//  DetailController.m
//  gzSpace
//
//  Created by PAAT on 2018/11/7.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "DetailController.h"

@interface DetailController ()
@property (nonatomic,strong)UIWebView *webView;
@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"详情";
    
    self.webView = [[UIWebView alloc]init];
    self.webView.frame = [UIScreen mainScreen].bounds;
    NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.jianshu.com/p/bf04afceb1a6"]];
    [self.webView loadRequest:request];
    [self.view addSubview:self.webView];
}

- (void)backAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

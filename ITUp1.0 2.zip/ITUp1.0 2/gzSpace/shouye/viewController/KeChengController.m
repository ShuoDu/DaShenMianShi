//
//  KeChengController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "KeChengController.h"
#import "ProjectViewCell.h"
#import "xinWenDetail/DetailController.h"
static NSString *identify = @"ProjectViewCell";
@interface KeChengController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UICollectionView *myClView;
@end

@implementation KeChengController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"课程";
    [self setCllView];
}

//选择元宝视图
- (void)setCllView {
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    self.myClView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT-54) collectionViewLayout:layout];
    self.myClView.delegate = self;
    self.myClView.dataSource = self;
    self.myClView.backgroundColor = NewViewBack;
    [self.view addSubview:self.myClView];
    [self.myClView  registerNib:[UINib nibWithNibName:@"ProjectViewCell" bundle:nil] forCellWithReuseIdentifier:identify];
//    [self.myClView registerClass:[ProjectViewCell class] forCellWithReuseIdentifier:identify];
}

#pragma mark collection代理方法

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 10;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ProjectViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identify forIndexPath:indexPath];
    cell.layer.masksToBounds = YES;
//    cell.layer.cornerRadius = 3;
    cell.layer.shadowColor=[UIColor blackColor].CGColor;
    //shadowColor阴影颜色
    cell.layer.shadowOffset=CGSizeMake(4,4);
    //shadowOffset阴影偏移,x向右偏移4,y向下偏移4,默认(0,-3),这个跟shadowRadius配合使用
    cell.layer.shadowOpacity=0;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake((WIDTH-30)/2,187);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(15, 10, 15, 10);//（上、左、下、右）
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    DetailController *detail = [[DetailController alloc]init];
    [self.navigationController pushViewController:detail animated:YES];
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath {
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

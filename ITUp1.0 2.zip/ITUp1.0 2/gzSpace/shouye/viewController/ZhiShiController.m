//
//  ZhiShiController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "ZhiShiController.h"

@interface ZhiShiController ()

@end

@implementation ZhiShiController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"知识";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

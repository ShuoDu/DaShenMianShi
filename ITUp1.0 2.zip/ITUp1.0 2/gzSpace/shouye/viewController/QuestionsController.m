//
//  QuestionsController.m
//  gzSpace
//
//  Created by PAAT on 2018/11/24.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "QuestionsController.h"

@interface QuestionsController ()

@end

@implementation QuestionsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"疑难问题";
}

@end

//
//  MainModel.h
//  gzSpace
//
//  Created by 杜硕 on 2018/11/1.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainModel : NSObject<YYModel>
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *content;
@property (nonatomic,strong)NSString *contentUrl;
@property (nonatomic,strong)NSString *time;
@property (nonatomic,strong)NSString *dianzan;
@property (nonatomic,strong)NSString *pinglun;
@property (nonatomic,strong)NSString *imgOneUrl;
@property (nonatomic,strong)NSString *lable;
@property (nonatomic,strong)NSString *yuedu;
@end

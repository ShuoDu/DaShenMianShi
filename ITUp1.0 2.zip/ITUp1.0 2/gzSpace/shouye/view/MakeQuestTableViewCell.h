//
//  MakeQuestTableViewCell.h
//  gzSpace
//
//  Created by 杜硕 on 2018/10/13.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>
@class questModel;
@interface MakeQuestTableViewCell : UITableViewCell
- (void)loadData:(questModel *)data;
@end

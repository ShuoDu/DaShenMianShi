//
//  YDBClientServe.h
//  EasyRiding
//
//  Created by 智享单车 on 2017/12/14.
//  Copyright © 2017年 易代步. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YDBClientServe : UIView
+ (instancetype)insWithCallback:(void(^)(NSInteger))callback;
@end

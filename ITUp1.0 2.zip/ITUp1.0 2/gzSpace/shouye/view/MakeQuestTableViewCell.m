//
//  MakeQuestTableViewCell.m
//  gzSpace
//
//  Created by 杜硕 on 2018/10/13.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MakeQuestTableViewCell.h"
#import "questModel.h"
@interface MakeQuestTableViewCell()
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet UIImageView *backImg;
@property (weak, nonatomic) IBOutlet UILabel *title;

@end

@implementation MakeQuestTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.backView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.backView.layer.shadowOffset = CGSizeMake(1,1);//shadowOffset阴影偏移,x向右偏移4，y向下偏移4，默认(0, -3),这个跟shadowRadius配合使用
    self.backView.layer.shadowOpacity = 0.3;//阴影透明度，默认0
    self.backView.layer.shadowRadius = 3;//阴影半径，默认3
    self.backView.layer.cornerRadius = 8;
    
//    self.backImg.layer.shadowOffset = CGSizeMake(1,1);//shadowOffset阴影偏移,x向右偏移4，y向下偏移4，默认(0, -3),这个跟shadowRadius配合使用
//    self.backImg.layer.shadowOpacity = 0.3;//阴影透明度，默认0
//    self.backImg.layer.shadowRadius = 3;//阴影半径，默认3
    self.backImg.layer.cornerRadius = 5;
    self.backImg.layer.masksToBounds = YES;
}

- (void)loadData:(questModel *)data {
    self.title.text = data.title;
    NSString * imgStr = [ImgHost stringByAppendingString:data.quest_img] ;
    [self.backImg sd_setImageWithURL:[NSURL URLWithString:imgStr]];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

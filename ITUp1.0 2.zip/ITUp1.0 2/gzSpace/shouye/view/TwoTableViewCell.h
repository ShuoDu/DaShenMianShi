//
//  TwoTableViewCell.h
//  gzSpace
//
//  Created by 杜硕 on 2018/9/23.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainModel.h"
@interface TwoTableViewCell : UITableViewCell
-(void)writeModel:(MainModel *)model;
@end

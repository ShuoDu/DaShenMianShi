//
//  ThreeTableViewCell.h
//  gzSpace
//
//  Created by 杜硕 on 2018/9/23.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>
//声明一个名为 AddToCartsBlock  无返回值，参数为XSMyFavoriteTableViewCell 类型的block
typedef void (^AddToCartsBlock) (int);
@interface ThreeTableViewCell : UITableViewCell
- (void)writeData:(NSMutableArray *)dataArray;
@property(nonatomic, copy) AddToCartsBlock addToCartsBlock;
@end

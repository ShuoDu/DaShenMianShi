//
//  MainOneCell.m
//  gzSpace
//
//  Created by 智享单车 on 2017/12/12.
//  Copyright © 2017年 智享单车. All rights reserved.
//

#import "MainOneCell.h"
#import "questModel.h"
//#import "MainMessageModel.h"
@interface MainOneCell()
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (strong, nonatomic) IBOutlet UILabel *type;
@property (strong, nonatomic) IBOutlet UILabel *yuedu;
@property (strong, nonatomic) IBOutlet UILabel *pinglun;
@end
@implementation MainOneCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.backView.layer.shadowOffset = CGSizeMake(1,1);//shadowOffset阴影偏移,x向右偏移4，y向下偏移4，默认(0, -3),这个跟shadowRadius配合使用
    self.backView.layer.shadowOpacity = 0.3;//阴影透明度，默认0
    self.backView.layer.shadowRadius = 3;//阴影半径，默认3
    self.backView.layer.cornerRadius = 8;
}

- (void)loadData:(questModel *)data{
    self.title.text = data.title;
    self.time.text = data.time;
    NSString * imgStr = [ImgHost stringByAppendingString:data.quest_img] ;
    [self.photo sd_setImageWithURL:[NSURL URLWithString:imgStr]];
}

@end

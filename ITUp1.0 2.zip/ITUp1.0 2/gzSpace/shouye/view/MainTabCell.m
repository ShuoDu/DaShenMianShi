//
//  MainTabCell.m
//  gzSpace
//
//  Created by 智享单车 on 2018/5/15.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MainTabCell.h"
#import "UIButton+JKImagePosition.h"
@interface MainTabCell ()
@property (strong, nonatomic) IBOutlet UILabel *title;
@property (strong, nonatomic) IBOutlet UILabel *lingyu;
@property (strong, nonatomic) IBOutlet UILabel *yuedu;
@property (strong, nonatomic) IBOutlet UILabel *pinglun;
@property (strong, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIImageView *titleLogo;
@property (weak, nonatomic) IBOutlet UILabel *biaoqian;
@property (weak, nonatomic) IBOutlet UILabel *content;
@end

@implementation MainTabCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.titleLogo.layer.masksToBounds = YES;
    self.titleLogo.layer.cornerRadius = 30;
    self.biaoqian.layer.masksToBounds = YES;
    self.biaoqian.layer.cornerRadius = 30;
    self.biaoqian.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.444f];
}

- (void)loadData:(MainModel *)data {
    self.title.text = data.title;
    self.content.text = data.content;
    self.time.text = data.time;
    self.yuedu.text =[NSString stringWithFormat:@"%@人看过",data.yuedu];
    self.pinglun.text = data.pinglun;
    self.biaoqian.text = data.lable;
//    NSLog(@"%@",data.imgOneUrl);
    NSString *imgStr = [ImgHost stringByAppendingString:data.imgOneUrl];
//    NSLog(@"%@",imgStr);
    [self.photo sd_setImageWithURL:[NSURL URLWithString:imgStr]];
}

@end

//
//  YuYinLabCell.h
//  gzSpace
//
//  Created by PAAT on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void (^AddToCartsBlock) (int);
@interface YuYinLabCell : UITableViewCell
- (void)writeData:(NSMutableArray *)dataArray;
@property(nonatomic, copy) AddToCartsBlock addToCartsBlock;
@end

NS_ASSUME_NONNULL_END

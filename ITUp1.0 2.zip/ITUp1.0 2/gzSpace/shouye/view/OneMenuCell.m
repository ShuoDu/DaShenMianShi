 //
//  OneMenuCell.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/17.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "OneMenuCell.h"
@interface OneMenuCell()
@property (weak, nonatomic) IBOutlet UIButton *one;
@property (weak, nonatomic) IBOutlet UIButton *two;
@property (weak, nonatomic) IBOutlet UIButton *three;
@property (weak, nonatomic) IBOutlet UIButton *four;
@property (weak, nonatomic) IBOutlet UIButton *five;

@end


@implementation OneMenuCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

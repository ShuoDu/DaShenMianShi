//
//  ThreeTableViewCell.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/23.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "ThreeTableViewCell.h"
#import "MainModel.h"
#import "DetailController.h"
@interface ThreeTableViewCell()
@property(nonatomic,strong)NSMutableArray *dataArray;
@property(nonatomic,strong)NSMutableArray *urlArray;
@property(nonatomic,strong)UIScrollView *scroll ;

@end
@implementation ThreeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)writeData:(NSMutableArray *)dataArray {
    NSLog(@"课程数据%@",dataArray);
    self.dataArray = [NSMutableArray arrayWithArray:dataArray];
    self.urlArray = [NSMutableArray arrayWithArray:dataArray];
//    [self addMyScroll];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self addMyScroll];
}

- (void)addMyScroll {
    [self.scroll removeFromSuperview];
    self.scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 1, WIDTH, 148)];
    self.scroll.showsHorizontalScrollIndicator = NO;
    self.scroll.showsVerticalScrollIndicator = NO;
    self.scroll.pagingEnabled = YES;
    self.scroll.backgroundColor = [UIColor whiteColor];
    [self.scroll setContentSize:CGSizeMake(WIDTH*2, 0)];
    [self addSubview:self.scroll];
    if (self.dataArray.count!=0) {
        NSMutableArray *imgStrArr = [[NSMutableArray alloc]init];
        for (MainModel *model in self.dataArray) {
            NSString *imgUrl = model.imgOneUrl;
            NSString *imgStr = [ImgHost stringByAppendingString:imgUrl];
            [imgStrArr addObject:imgStr];
            [self.urlArray addObject:model.contentUrl];
        }
        
        for (int i = 0; i<3; i++) {
            MainModel *model = self.dataArray[i];
            UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(10+(i*((WIDTH-20)/2)), 8, (WIDTH-20)/2-10, 130)];
            img.backgroundColor = [UIColor yellowColor];
            img.tag = 200+i;
            [img sd_setImageWithURL:[NSURL URLWithString:imgStrArr[i]]];
            [self.scroll addSubview:img];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTap:)];
            // 允许用户交互
            img.userInteractionEnabled = YES;
            [img addGestureRecognizer:tap];
            
            UILabel *titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, img.bottom-60, img.width, 30)];
            titleLable.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.444f];
            titleLable.text = model.title;
            titleLable.textColor = [UIColor whiteColor];
            titleLable.font = [UIFont boldSystemFontOfSize:14];
            titleLable.textAlignment = NSTextAlignmentCenter;
            [img addSubview:titleLable];
            UILabel *contentLable = [[UILabel alloc]initWithFrame:CGRectMake(0, titleLable.bottom, img.width, 20)];
            contentLable.text = model.content;
            contentLable.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.444f];
            contentLable.textColor = [UIColor whiteColor];
            contentLable.font = [UIFont systemFontOfSize:12];
            contentLable.textAlignment = NSTextAlignmentCenter;
            [img addSubview:contentLable];
        }
    }
}

- (void)doTap:(UITapGestureRecognizer *)sender {
    //用tag传值判断
    UIView *view = sender.view;
    NSLog(@"小表%ld",view.tag);
    int tags = (int)view.tag;
    if (self.addToCartsBlock) {
        self.addToCartsBlock(tags);
    }

    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

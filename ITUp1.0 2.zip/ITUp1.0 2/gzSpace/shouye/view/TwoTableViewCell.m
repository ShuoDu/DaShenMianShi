//
//  TwoTableViewCell.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/23.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "TwoTableViewCell.h"
@interface TwoTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@end

@implementation TwoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

}
- (void)writeModel:(MainModel *)model {
    self.titleLab.text = model.title;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

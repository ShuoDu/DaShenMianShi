//
//  YDBClientServe.m
//  EasyRiding
//
//  Created by 智享单车 on 2017/12/14.
//  Copyright © 2017年 易代步. All rights reserved.
//

#import "YDBClientServe.h"
#import "UIButton+JKImagePosition.h"
#import "UIColor+YYAdd.h"
@interface YDBClientServe()
@property (weak, nonatomic) IBOutlet UIView *bottomBackView;
@property (copy, nonatomic) void (^callback)(NSInteger);
@property (weak, nonatomic) IBOutlet UIButton *clientOneBtn;
@property (weak, nonatomic) IBOutlet UIButton *clientTwoBtn;
@property (weak, nonatomic) IBOutlet UIButton *clientThreeBtn;
@property (weak, nonatomic) IBOutlet UIButton *clientFourBtn;
@property (strong, nonatomic) IBOutlet UIButton *helpBtn;
@end
@implementation YDBClientServe

+ (instancetype)insWithCallback:(void(^)(NSInteger))callback {
    YDBClientServe *view = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:nil options:nil].firstObject;
    view.backgroundColor =[UIColor whiteColor];
    view.callback = callback;
    return view;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.clientOneBtn jk_setImagePosition:2 spacing:15];
    [self.clientTwoBtn jk_setImagePosition:2 spacing:15];
    [self.clientThreeBtn jk_setImagePosition:2 spacing:15];
    [self.clientFourBtn jk_setImagePosition:2 spacing:15];
    
    CALayer *layer = [self.bottomBackView layer];
    layer.shadowOffset = CGSizeMake(0, 0); //(0,0)时是四周都有阴影
    layer.shadowRadius = 3.0;
    layer.shadowColor = [UIColor blackColor].CGColor;
    layer.shadowOpacity = 0.3;
    layer.cornerRadius = 16;
}


- (IBAction)clienOneAction:(id)sender {
    UIButton *oneBtn = sender;
    oneBtn.tag = 401;
    if (self.callback) {
        self.callback(oneBtn.tag);
    }

}

- (IBAction)clienTwoAction:(id)sender {
    UIButton *twoBtn = sender;
    twoBtn.tag = 402;
    if (self.callback) {
        self.callback(twoBtn.tag);
    }

}

- (IBAction)clientThreeAction:(id)sender {
    UIButton *threeBtn = sender;
    threeBtn.tag = 405;
    if (self.callback) {
        self.callback(threeBtn.tag);
    }

}

- (IBAction)clentFourAction:(id)sender {
    UIButton *threeBtn = sender;
    threeBtn.tag = 403;
    if (self.callback) {
        self.callback(threeBtn.tag);
    }
}

- (IBAction)clentFiveAction:(id)sender {
    UIButton *fourBtn = sender;
    fourBtn.tag = 404;
    if (self.callback) {
        self.callback(fourBtn.tag);
    }
}


@end

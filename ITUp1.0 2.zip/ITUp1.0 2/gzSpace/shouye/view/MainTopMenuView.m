//
//  MainTopMenuView.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/15.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MainTopMenuView.h"

@interface MainTopMenuView()
@property (nonatomic, copy) void (^callback)(NSInteger);
@end

@implementation MainTopMenuView

+ (instancetype)ins:(void(^)(NSInteger))callback {
    MainTopMenuView *view = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:nil options:nil].firstObject;
    view.callback = callback;
    return view;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = ZTColor;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.backgroundColor = [UIColor whiteColor];
}

@end

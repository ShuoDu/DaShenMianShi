//
//  YuYinLabCell.m
//  gzSpace
//
//  Created by PAAT on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "YuYinLabCell.h"
#import "MainModel.h"
@interface YuYinLabCell()
@property(nonatomic,strong)NSMutableArray *dataArray;
@property(nonatomic,strong)UIScrollView *scroll ;
@property(nonatomic,strong)UILabel *title;
@end

@implementation YuYinLabCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)writeData:(NSMutableArray *)dataArray {
    self.dataArray = dataArray;
    [self addMyScroll];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self addMyScroll];
}

- (void)addMyScroll {
    [self.scroll removeFromSuperview];
    self.scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 1, WIDTH, 98)];
    self.scroll.showsHorizontalScrollIndicator = NO;
    self.scroll.showsVerticalScrollIndicator = NO;
    self.scroll.pagingEnabled = YES;
    self.scroll.backgroundColor = [UIColor whiteColor];
    [self.scroll setContentSize:CGSizeMake(WIDTH*2, 0)];
    [self addSubview:self.scroll];
    
    if (self.dataArray.count!=0) {
        NSMutableArray *imgStrArr = [[NSMutableArray alloc]init];
        for (MainModel *model in self.dataArray) {
            NSString *imgUrl = model.imgOneUrl;
            NSString *imgStr = [ImgHost stringByAppendingString:imgUrl];
            [imgStrArr addObject:imgStr];
        }
        for (int i = 0; i<self.dataArray.count; i++) {
            UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(10+(i*((WIDTH-60))), 5, (WIDTH-60)-10, 90)];
            img.backgroundColor = [UIColor whiteColor];
             img.tag = 200+i;
            img.image = [UIImage imageNamed:@"1"];
            [img sd_setImageWithURL:[NSURL URLWithString:imgStrArr[i]]];
            img.layer.cornerRadius = 5;
            img.layer.masksToBounds = YES;
            [self.scroll addSubview:img];
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTap:)];
            // 允许用户交互
            img.userInteractionEnabled = YES;
            [img addGestureRecognizer:tap];
            self.title = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,  img.width, img.height)];
            self.title.text = @"关于面试礼仪，你知道哪些？需要注意哪些细节？";
            self.title.textAlignment = NSTextAlignmentCenter;
            self.title.textColor = [UIColor whiteColor];
            self.title.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.444f];
            self.title.font = [UIFont systemFontOfSize:14];
            self.title.numberOfLines = 2;
            [img addSubview:self.title];
            
        }
    }  
}
- (void)doTap:(UITapGestureRecognizer *)sender {
    //用tag传值判断
    UIView *view = sender.view;
    NSLog(@"小表%ld",view.tag);
    int tags = (int)view.tag;
    if (self.addToCartsBlock) {
        self.addToCartsBlock(tags);
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end

//
//  ZhiHuController.m
//  CodeDemo
//
//  Created by wangrui on 2017/4/14.
//  Copyright © 2017年 wangrui. All rights reserved.
//
//  Github地址：https://github.com/wangrui460/WRNavigationBar

#import "LaGouController.h"
#import "StoreController.h"
#import "AppDelegate.h"
#import <SDCycleScrollView/SDCycleScrollView.h>
#import "MainModel.h"
#import "MainOneCell.h"
#import "OneMenuCell.h"
#import "InfoSwitchController.h"
#import "YDBClientServe.h"
#import "MainTabCell.h"
#import "LedgeThreeController.h"
#import "QuestBankController.h"
#import "MakeQuestController.h"
#import "InterViewController.h"
#import "ThreeTableViewCell.h"
#import "TwoTableViewCell.h"
#import "YuYinLabCell.h"
#import<AVFoundation/AVFoundation.h>//语音解读
#import "XinWenController.h"
#import "KeChengController.h"
#import "ZhiShiController.h"
#import "DetailController.h"
#import "FaceNeedController.h"
#import "QuestionsController.h"
#define NAVBAR_COLORCHANGE_POINT (-IMAGE_HEIGHT + NAV_HEIGHT)
#define NAV_HEIGHT 64
#define IMAGE_HEIGHT 200
#define SCROLL_DOWN_LIMIT 70
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define LIMIT_OFFSET_Y -(IMAGE_HEIGHT + SCROLL_DOWN_LIMIT)
static NSString *oneCell = @"MainOneCell";
static NSString *menuCell = @"OneMenuCell";
static NSString *mainTableCell = @"MainTabCell";
static NSString *twoCell = @"TwoTableViewCell";
static NSString *threeCell = @"ThreeTableViewCell";
static NSString *yuYin = @"YuYinLabCell";
@interface LaGouController () <UITableViewDelegate, UITableViewDataSource, SDCycleScrollViewDelegate>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)SDCycleScrollView *advView;
@property (nonatomic,strong)UIButton *searchButton;
@property (nonatomic,strong)UIBarButtonItem *rightItem;
@property (nonatomic,strong)UIBarButtonItem *leftItem;
@property (nonatomic,strong)AVSpeechSynthesizer * synthsizer;
@property (nonatomic,strong)NSMutableArray *project_array;
@property (nonatomic,strong)NSMutableArray *news_array;
@property (nonatomic,strong)NSMutableArray *interview_array;
@property (nonatomic,strong)NSMutableArray *message_array;
@property (nonatomic,strong)NSMutableArray *problem_array;
@property (nonatomic,strong)NSMutableArray *point_array;
@end

@implementation LaGouController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    self.navigationController.navigationBar.hidden = NO;
    [self.synthsizer pauseSpeakingAtBoundary:AVSpeechBoundaryImmediate];//暂停
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //请求数据
    [self loadData];
    self.navigationItem.title = @"首页";
    self.view.backgroundColor = [UIColor blueColor];
    // 知识树，面试题库，视频课程库，做题，模拟笔试
//    [self setupNavItems];
    self.tableView.contentInset = UIEdgeInsetsMake(IMAGE_HEIGHT-50 , 0, 0, 0);
    [self.tableView addSubview:self.advView];
//    [self.tableView registerNib:[UINib nibWithNibName:@"MainOneCell" bundle:nil] forCellReuseIdentifier:oneCell];
//    [self.tableView registerNib:[UINib nibWithNibName:@"OneMenuCell" bundle:nil] forCellReuseIdentifier:menuCell];
    [self.tableView registerNib:[UINib nibWithNibName:@"MainTabCell" bundle:nil] forCellReuseIdentifier:mainTableCell];
    [self.tableView registerNib:[UINib nibWithNibName:@"ThreeTableViewCell" bundle:nil] forCellReuseIdentifier:threeCell];
    [self.tableView registerNib:[UINib nibWithNibName:@"TwoTableViewCell" bundle:nil] forCellReuseIdentifier:twoCell];
    [self.tableView registerNib:[UINib nibWithNibName:@"YuYinLabCell" bundle:nil] forCellReuseIdentifier:yuYin];
//     self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    self.tableView.backgroundColor = NewViewBack;
}

- (void)setupNavItems {
    self.rightItem = [[UIBarButtonItem alloc]initWithTitle:@"技能" style:UIBarButtonItemStyleDone target:self action:@selector(test)];
    self.rightItem.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = self.rightItem;
    self.leftItem = [[UIBarButtonItem alloc]initWithTitle:@"侧边栏" style:UIBarButtonItemStyleDone target:self action:@selector(cebian)];
    self.leftItem.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = self.leftItem;
}

- (void)loadData {
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"main/list/"];
    NSLog(@"请求地址%@",urls);
    [CYXHttpRequest get:urls params:nil success:^(id responseObj) {
        NSDictionary * dataDic = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"%@",dataDic);
        //新闻
        NSMutableArray *news_array = dataDic[@"news_list"];
        NSMutableArray *array = [NSMutableArray new];
        for (NSDictionary *dict in news_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [array addObject:newsModel];
        }
        self.news_array = array;
        //轮播
        NSMutableArray *message_data = [NSMutableArray new];
        NSMutableArray *message_array = dataDic[@"message_list"];
        for (NSDictionary *dict in message_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [message_data addObject:newsModel];
        }
        self.message_array = message_data;
        //知识点
        NSMutableArray *point_data = [NSMutableArray new];
        NSMutableArray *point_array = dataDic[@"point_list"];
        for (NSDictionary *dict in point_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [point_data addObject:newsModel];
        }
        self.point_array = point_data;
        //面试须知
        NSMutableArray *inter_data = [NSMutableArray new];
        NSMutableArray *inter_array = dataDic[@"interview_list"];
        for (NSDictionary *dict in inter_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [inter_data addObject:newsModel];
        }
        self.interview_array = inter_data;
        //课程
        NSMutableArray *project_data = [NSMutableArray new];
        NSMutableArray *project_array = dataDic[@"project_list"];
        for (NSDictionary *dict in project_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [project_data addObject:newsModel];
        }
        self.project_array = project_data;
        
        //疑难问题
        NSMutableArray *problem_data = [NSMutableArray new];
        NSMutableArray *problem_array = dataDic[@"problem"];
        for (NSDictionary *dict in problem_array) {
            MainModel *newsModel = [MainModel yy_modelWithDictionary:dict];
            [problem_data addObject:newsModel];
        }
        self.problem_array = problem_data;
        [self.tableView reloadData];
  
    } failure:^(NSError *error) {
    }];
}

- (void)shaixuan {
    
}

- (void)cebian {
    [self.viewDeckController openSide:IIViewDeckSideLeft animated:YES];
}

- (void)test {
    InfoSwitchController *info = [[InfoSwitchController alloc]init];
    [self.navigationController pushViewController:info animated:NO];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//    self.navigationController.navigationBar.hidden = NO;
    CGFloat offsetY = scrollView.contentOffset.y;
    //限制下拉的距离
    if(offsetY < LIMIT_OFFSET_Y) {
        [scrollView setContentOffset:CGPointMake(0, LIMIT_OFFSET_Y)];
    }
    // 改变图片框的大小 (上滑的时候不改变)
    // 这里不能使用offsetY，因为当（offsetY < LIMIT_OFFSET_Y）的时候，y = LIMIT_OFFSET_Y 不等于 offsetY
    CGFloat newOffsetY = scrollView.contentOffset.y;
    if (newOffsetY < -IMAGE_HEIGHT) {
        self.advView.frame = CGRectMake(0, newOffsetY, kScreenWidth, -newOffsetY);
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.news_array.count;
    }
    if (section == 1) {
        return 1;
    }
    if (section == 2) {
        return self.point_array.count;
    }
    
    if (section == 3) {
        return 1;
    } else {
           return self.problem_array.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        MainModel *model = self.news_array[indexPath.row];
        //新闻
        TwoTableViewCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"TwoTableViewCell"];
        [cellOne writeModel:model];
        cellOne.backgroundColor = [UIColor clearColor];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellOne;
    } else if (indexPath.section == 1) {
        //课程

        ThreeTableViewCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"ThreeTableViewCell"];
        
        [cellOne writeData:self.project_array];
        cellOne.backgroundColor = [UIColor clearColor];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        __weak typeof(self) weakSelf = self;
        cellOne.addToCartsBlock = ^(int tags) {
            NSLog(@"过来了%d",tags);
            MainModel *model = self.project_array[tags-200];
            DetailController *detail = [[DetailController alloc]init];
            detail.contentUrl = model.contentUrl;
            [detail setHidesBottomBarWhenPushed:YES];
            [weakSelf.navigationController pushViewController:detail animated:YES];
        };
        return cellOne;
    } else if (indexPath.section == 2) {
        MainModel *model = self.point_array[indexPath.row];
        MainTabCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"MainTabCell"];
        [cellOne loadData:model];
        cellOne.backgroundColor = [UIColor clearColor];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellOne;
    } else if (indexPath.section == 3) {
        //面试须知
        YuYinLabCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"YuYinLabCell"];
        [cellOne writeData:self.interview_array];
        cellOne.backgroundColor = [UIColor clearColor];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        __weak typeof(self) weakSelf = self;
        cellOne.addToCartsBlock = ^(int tags) {
            NSLog(@"过来了%d",tags);
            MainModel *model = self.interview_array[tags-200];
            DetailController *detail = [[DetailController alloc]init];
            detail.contentUrl = model.contentUrl;
            [detail setHidesBottomBarWhenPushed:YES];
            [weakSelf.navigationController pushViewController:detail animated:YES];
        };
        return cellOne;
    } else {
        MainModel *model = self.problem_array[indexPath.row];
        MainTabCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"MainTabCell"];
        [cellOne loadData:model];
        cellOne.backgroundColor = [UIColor clearColor];
        cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
        cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
        return cellOne;
    }
}
// 返回组头部view的高度

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 45;
}

//返回每组头部view
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {

    UIView *headerView = [[UIView alloc]init];
    headerView.tag = section;
    headerView.backgroundColor = [UIColor whiteColor];
    
    UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(WIDTH-25, 15, 15, 15)];
    img.image = [UIImage imageNamed:@"next"];
    [headerView addSubview:img];
    
    UILabel * nextLabel = [[UILabel alloc]init];
    nextLabel.textColor = [UIColor lightGrayColor];
    nextLabel.font = [UIFont systemFontOfSize:13];
    nextLabel.frame = CGRectMake(WIDTH-65, 7.5, 40, 30);
    nextLabel.textAlignment = NSTextAlignmentRight;
    nextLabel.text = @"更多";
    [headerView addSubview:nextLabel];
   
    UILabel * titleLabel = [[UILabel alloc]init];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.frame = CGRectMake(15, 0, 100, 45);
    [headerView addSubview:titleLabel];
    
    NSArray *type = @[@"科技新闻",@"重点课程",@"知识点",@"面试须知",@"疑难问题"];
    titleLabel.text = type[section];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTap:)];
    // 允许用户交互
    headerView.userInteractionEnabled = YES;
    [headerView addGestureRecognizer:tap];
   
    return headerView;
}

- (void)doTap:(UITapGestureRecognizer *)sender {
    //用tag传值判断
    UIView *view = sender.view;
    switch (view.tag) {
        case 0: {
//            XinWenController *xinWen = [[XinWenController alloc]init];
            StoreController *xinwen = [[StoreController alloc]init];
            xinwen.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:xinwen animated:YES];
            break;
        }
           
        case 1: {
            KeChengController *keCheng = [[KeChengController alloc]init];
            keCheng.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:keCheng animated:YES];
        }
            break;
        case 2:{
            ZhiShiController *zhishi = [[ZhiShiController alloc]init];
            zhishi.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:zhishi animated:YES];
        }
            break;
        case 3:{
            FaceNeedController *need = [[FaceNeedController alloc]init];
            need.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:need animated:YES];
        }
            break;
        case 4:{
            QuestionsController *question = [[QuestionsController alloc]init];
            question.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:question animated:YES];
        }
            break;
        default:
            break;
    }

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 44;
    } else if (indexPath.section ==1 ) {
        return 150;
    } else if (indexPath.section ==3 ) {
        return 100;
    } else {
        return 85;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DetailController *detail = [[DetailController alloc]init];
    [detail setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:detail animated:YES];
    
//    if (indexPath.section == 0) {
//
//    } else if (indexPath.section ==1 ) {
//
//    } else if (indexPath.section ==3 ) {
//
//    } else {
//
//    }
 
}

#pragma mark - getter / setter
- (UITableView *)tableView {
    if (_tableView == nil) {
        CGRect frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight);
        _tableView = [[UITableView alloc] initWithFrame:frame
                                                  style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (UIImage *)imageWithImageSimple:(UIImage *)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContext(CGSizeMake(newSize.width*2, newSize.height*2));
    [image drawInRect:CGRectMake (0, 0, newSize.width*2, newSize.height*2)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

- (SDCycleScrollView *)advView {
    if (_advView == nil) {
//        NSMutableArray *aa = [NSMutableArray new];
//       NSArray *a = [NSArray arrayWithArray: self.message_array];
        NSArray *localImages = @[@"lagou0", @"lagou1", @"lagou2", @"lagou3"];
        _advView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, -IMAGE_HEIGHT, kScreenWidth, IMAGE_HEIGHT) imageNamesGroup:localImages];
        _advView.pageDotColor = [UIColor grayColor];
        _advView.autoScrollTimeInterval = 2;
        _advView.currentPageDotColor = [UIColor whiteColor];
        _advView.bannerImageViewContentMode = UIViewContentModeScaleAspectFill;
    }
    return _advView;
}

- (void)onClickLeft {
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)onClickRight {
    
}
- (void)onClickSearchBtn {
    
}





@end

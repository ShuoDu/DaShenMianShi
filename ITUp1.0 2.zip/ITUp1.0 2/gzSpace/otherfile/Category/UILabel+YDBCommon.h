//
//  UILabel+YDBCommon.h
//  EasyRiding
//
//  Created by 易代步 on 2017/8/16.
//  Copyright © 2017年 易代步. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (YDBCommon)

@end

//
//  CenterButton.h
//  NashaClient
//
//  Created by chinachong on 2016/11/3.
//  Copyright © 2016年 ChinaChong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CenterButton : UIButton
- (void)verticalImageAndTitle:(CGFloat)spacing;
@end

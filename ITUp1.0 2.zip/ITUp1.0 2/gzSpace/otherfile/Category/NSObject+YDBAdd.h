//
//  NSObject+YDBAdd.h
//  EasyRiding
//
//  Created by 易代步 on 2017/5/12.
//  Copyright © 2017年 易代步. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (YDBAdd)
+ (UIViewController *)getCurrentVC;
@end

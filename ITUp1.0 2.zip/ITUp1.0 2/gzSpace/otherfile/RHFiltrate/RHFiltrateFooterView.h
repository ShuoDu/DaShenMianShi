//
//  RHFiltrateFooterView.h
//  MCSchool
//
//  Created by 郭人豪 on 2016/12/24.
//  Copyright © 2016年 Abner_G. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RHFiltrateFooterView : UICollectionReusableView

@end

//
//  RHCollectionViewFlowLayout.h
//  MCSchool
//
//  Created by 郭人豪 on 2017/3/3.
//  Copyright © 2017年 Abner_G. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RHCollectionViewFlowLayout : UICollectionViewFlowLayout

@end

@protocol RHCollectionViewDelegateFlowLayout <UICollectionViewDelegateFlowLayout>

@end

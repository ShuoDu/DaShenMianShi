//
//  TableHeaderAnimationVC.h
//  YBTableViewHeaderAnimationDemo
//
//  Created by fengbang on 2018/7/11.
//  Copyright © 2018年 王颖博. All rights reserved.
//

#import "BaseController.h"

@interface TableHeaderAnimationVC : BaseController
@property (nonatomic, assign) NSInteger type;
@end

//
//  TableHeaderAnimationVC.m
//  YBTableViewHeaderAnimationDemo
//
//  Created by fengbang on 2018/7/11.
//  Copyright © 2018年 王颖博. All rights reserved.
//

#import "TableHeaderAnimationVC.h"
#import "UserInfoView.h"
#import "LoginController.h"
#import "AboutUsController.h"
CGFloat const kMaxScrollContentSizeY = 280;

@interface TableHeaderAnimationVC ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, copy) NSArray *dataArray;
@property (assign, nonatomic) CGFloat headerViewHeight;
@property (nonatomic,strong) UserInfoView *userInfoView;

@end

@implementation TableHeaderAnimationVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

#pragma mark - lazy
- (UITableView *)tableView {
    if (!_tableView) {
        UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT) style:UITableViewStyleGrouped];
        if (@available(iOS 11.0, *)) {
            tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        } else {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
        tableView.estimatedRowHeight = 44;
        tableView.estimatedSectionHeaderHeight = 10.;
        tableView.estimatedSectionFooterHeight = 0.1;
        tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        tableView.separatorInset = UIEdgeInsetsMake(0.5, 14, 0, 0);
        //占位用的view
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, FULL_SCREEN_WIDTH-100, self.headerViewHeight)];
        view.backgroundColor = [UIColor clearColor];
        tableView.tableHeaderView = view;
        tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 0.01)];
        [self.view addSubview:tableView];
        tableView.backgroundColor = NewViewBack;
        _tableView = tableView;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的";
    self.headerViewHeight = kUSER_INFO_HEADERVIEW_H;
    
    [self configUI];
    
    [self configData];
    
    [self configTopView];
    
//    [self loadData:@"Object-C基础"];
//    [self configBackButton];
}


- (void)loadData:(NSString *)type {
    NSDictionary *parm = @{@"typeOne":type};
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"qs/questTypeTwoList/"];
    
    [CYXHttpRequest get:urls params:parm success:^(id responseObj) {
        NSLog(@"%@",responseObj);
        //        NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
        //        [self.datasArray removeAllObjects];
        //        for (NSDictionary *dic in dataArray) {
        //
        //            [self.datasArray addObject:dic[@"title"]];
        //        }
        //        NSLog(@"%@",self.datasArray);
        //        [self.tableView reloadData];
    } failure:^(NSError *error) {
    }];
}

#pragma amrk - private
- (void)configData {
    self.dataArray = @[@[@"修改密码",@"清除缓存"],@[@"系统消息",@"关于我们"]];
}

- (void)configUI {
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

- (void)configBackButton {
    UIButton *backButton = [[UIButton alloc]initWithFrame:CGRectMake(10, 30, 22, 22)];
    [backButton setImage:[UIImage imageNamed:@"back_white"] forState:UIControlStateNormal];
    [backButton addTarget:self action:@selector(backBarButtonItemAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backButton];
}

- (void)backBarButtonItemAction {
    [self.viewDeckController closeSide:YES];
}

-(UIView *)configTopView {
    _userInfoView = [[UserInfoView alloc]initWithFrame:CGRectMake(0, 0, FULL_SCREEN_WIDTH, self.headerViewHeight)];
//    if (self.type == 0) {
//        _userInfoView.animationType = FBUserInfoHeaderViewAnimationTypeNone;
//    }else if (self.type == 1) {
//        _userInfoView.animationType = FBUserInfoHeaderViewAnimationTypeScale;
//    }else {
        _userInfoView.animationType = FBUserInfoHeaderViewAnimationTypeCircle;
//    }
    [self.view addSubview:_userInfoView];
    [_userInfoView setInfoWithNoLoginData];
    return _userInfoView;
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *arr = self.dataArray[section];
    return arr.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *kCellId = @"cellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellId];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:kCellId];
    }
    
    NSArray *iconArray = @[@[@"mine_list_change_password",@"mine_list_binding"],@[@"mine_list_message_setting",@"mine_list_about"]];
    NSArray *arr = self.dataArray[indexPath.section];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text = arr[indexPath.row];
    cell.textLabel.font = [UIFont systemFontOfSize:15.];
    cell.textLabel.textColor = [UIColor grayColor];
//    cell.detailTextLabel.text = [NSString stringWithFormat:@"section:%ld-row:%ld",indexPath.section,indexPath.row];
    cell.detailTextLabel.textColor = [UIColor lightGrayColor];
    NSArray *icons = iconArray[indexPath.section];
    cell.imageView.image = [UIImage imageNamed:icons[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if (indexPath.section==0) {
        if (indexPath.row == 0) {
            LoginController * login = [[LoginController alloc]init];
            login.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:login animated:YES];
        }
    }
    if (indexPath.section==1) {
        if (indexPath.row==1) {
            AboutUsController *about = [[AboutUsController alloc]init];
            about.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:about animated:YES];
        }
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] init];
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] init];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    CGFloat offsetY = scrollView.contentOffset.y;
    CGFloat width = self.view.frame.size.width;
    CGRect frame = self.userInfoView.frame;
    //FBLog(@"偏移量:%.2f",scrollView.contentOffset.y);
    
    if (self.userInfoView.animationType == FBUserInfoHeaderViewAnimationTypeCircle) {
        if (offsetY < 0) {
            frame.size.height = (self.headerViewHeight + ABS(offsetY))>kMaxScrollContentSizeY?kMaxScrollContentSizeY:(self.headerViewHeight + ABS(offsetY));
            frame.origin.y = 0;//及时归零
            if (self.headerViewHeight+ABS(offsetY)>kMaxScrollContentSizeY) {
                scrollView.contentOffset = CGPointMake(0, self.headerViewHeight-kMaxScrollContentSizeY);
            }
        } else {//向上滑
            //取消向上滑到顶的弹簧效果
            scrollView.contentOffset = CGPointZero;
            frame.size.height = self.headerViewHeight;
            frame.origin.y = 0;//-offsetY
        }
        self.userInfoView.frame = frame;
        
    }else if (self.userInfoView.animationType == FBUserInfoHeaderViewAnimationTypeScale) {
        
        if (offsetY < 0) {
            frame.size.height = (self.headerViewHeight + ABS(offsetY))>kMaxScrollContentSizeY?kMaxScrollContentSizeY:(self.headerViewHeight + ABS(offsetY));
            frame.origin.y = 0;//及时归零
            
            CGFloat f = (self.headerViewHeight + ABS(offsetY)) / self.headerViewHeight;//缩放比
            //拉伸后的图片的frame应该是同比例缩放。
            frame =  CGRectMake(- (width * f - width) / 2, 0, width * f, (self.headerViewHeight + ABS(offsetY)));
            
        } else {//向上滑
            //取消向上滑到顶的弹簧效果
            scrollView.contentOffset = CGPointZero;
            frame.size.height = self.headerViewHeight;
            frame.origin.y = 0;//-offsetY
        }
        self.userInfoView.frame = frame;
    }
    
}

// scrollViewWillEndDragging，这个方法内判断一下，contentOffset.y 值，如果超过多少值，那么自动回调一个 block，可实现下拉刷新
//松手时触发
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    
    CGFloat offsetY = scrollView.contentOffset.y;
    if (-offsetY > 70) {
    }
}


@end

//
//  AboutUsController.m
//  gzSpace
//
//  Created by PAAT on 2018/11/23.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "AboutUsController.h"

@interface AboutUsController ()

@end

@implementation AboutUsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"关于我们";
}



@end

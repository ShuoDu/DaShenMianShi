//
//  BaseController.h
//  gzSpace
//
//  Created by 智享单车 on 2017/12/11.
//  Copyright © 2017年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseController : UIViewController

@end

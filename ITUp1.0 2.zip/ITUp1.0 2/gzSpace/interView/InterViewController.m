//
//  InterViewController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/22.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "InterViewController.h"

@interface InterViewController ()

@end

@implementation InterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"面试";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}



@end

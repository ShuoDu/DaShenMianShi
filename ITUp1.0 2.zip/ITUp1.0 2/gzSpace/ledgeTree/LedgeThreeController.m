//
//  LedgeThreeController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/22.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "LedgeThreeController.h"
#import "Node.h"
#import "TreeTableView.h"
#import "QuestDetailController.h"
#import "QuestDetailController.h"
#import "CYLTabBarController.h"
#import "QuestionSpaceController.h"
static NSString *oneCell = @"MainOneCell";
@interface LedgeThreeController () <UITableViewDelegate,TreeTableCellDelegate>
@property (nonatomic,strong) UITableView *tableVIew;
@property (nonatomic,strong) NSMutableArray *arr;
@property (nonatomic,strong) NSMutableArray *datasArray;
@property (nonatomic,strong) NSMutableArray *twoArray;
@end

@implementation LedgeThreeController



- (void)viewDidLoad {
    [super viewDidLoad];
    self.datasArray = [NSMutableArray new];
    self.title = @"面试题库";
    
    NSLog(@"类型%@",self.typeOne);
//
//   [self loadData:self.typeOne];
    [self loadData:self.typeOne];
  
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
//    [self loadData:self.typeOne];
//    [self initData];
}
//获取数据
- (void)loadData:(NSString *)type {
    NSDictionary *parm = @{@"type":type};
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"qs/questDetail/"];
    
    [CYXHttpRequest get:urls params:parm success:^(id responseObj) {
     
        NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
            [self.datasArray removeAllObjects];
            self.datasArray = [NSMutableArray arrayWithArray:dataArray];
                for (NSDictionary *dic in dataArray) {
                    NSLog(@"标题%@",dic[@"title"]);
                }
              [self initData];
//                [self.tableView reloadData];
    } failure:^(NSError *error) {
    }];
    
}


//- (void)loadTwoData:(NSString *)nodelName {
//    NSDictionary *parm = @{@"type":nodelName};
//    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"qs/questionList/"];
//
//    [CYXHttpRequest get:urls params:parm success:^(id responseObj) {
//
//        NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
//
//        [self.twoArray removeAllObjects];
//        for (NSDictionary *dic in dataArray) {
//
//            [self.twoArray addObject:dic[@"title"]];
//        }
//         NSLog(@"标签2%@",self.twoArray);
////        [self initTwoData];
//        //                [self.tableView reloadData];
//    } failure:^(NSError *error) {
//    }];
//}

- (void)initData {
    NSMutableArray *nodelArry = [[NSMutableArray alloc]init];
    for (int i = 0 ; i<self.datasArray.count; i++) {
        NSDictionary *dic = self.datasArray[i];
//        NSLog(@"名字%@",dic[@"title"]); // 把第二层也合到第一层
        Node *gen1 = [[Node alloc] initWithParentId:-1 nodeId:i name:dic[@"title"] depth:0 expand:YES];
        [nodelArry addObject:gen1];
    }
//    NSLog(@"nodel的个数%ld",nodelArry.count);
//    //----------------------------------根节点--------------------------------------------
//    Node *gen1 = [[Node alloc] initWithParentId:-1 nodeId:0 name:@"RunTime" depth:0 expand:YES];
//    Node *gen2 = [[Node alloc] initWithParentId:-1 nodeId:1 name:@"RunLoop" depth:0 expand:YES];
//    Node *gen3 = [[Node alloc] initWithParentId:-1 nodeId:2 name:@"Ios语法基础(100道)" depth:0 expand:YES];
//    Node *gen4 = [[Node alloc] initWithParentId:-1 nodeId:3 name:@"IosUI控件基础(50道)" depth:0 expand:YES];
//
//    //----------------------------------子节点--------------------------------------------
//    Node *zi11 = [[Node alloc] initWithParentId:0 nodeId:101 name:@"RunTime的基础知识1" depth:1 expand:NO];
//    Node *zi12 = [[Node alloc] initWithParentId:0 nodeId:102 name:@"RunTime的基础知识2" depth:1 expand:NO];
//    Node *zi13 = [[Node alloc] initWithParentId:0 nodeId:103 name:@"RunTime的基础知识3" depth:1 expand:NO];
//
//    Node *zi21 = [[Node alloc] initWithParentId:1 nodeId:201 name:@"RunLoop知识1" depth:1 expand:NO];
//    Node *zi22 = [[Node alloc] initWithParentId:1 nodeId:202 name:@"RunLoop知识2" depth:1 expand:NO];
//    Node *zi23 = [[Node alloc] initWithParentId:1 nodeId:203 name:@"RunLoop知识3" depth:1 expand:NO];
//
//    Node *zi41 = [[Node alloc] initWithParentId:2 nodeId:301 name:@"Ios语法基础1" depth:1 expand:NO];
//    Node *zi42 = [[Node alloc] initWithParentId:2 nodeId:302 name:@"Ios语法基础2" depth:1 expand:NO];
//    Node *zi5 = [[Node alloc] initWithParentId:3 nodeId:401 name:@"IosUI控件基础(50道)" depth:1 expand:NO];
    
//    NSArray *data = [NSArray arrayWithObjects:gen1,zi11,zi12,zi13,gen2,zi21,zi22,zi23,gen3,zi41,zi42,gen4,zi5, nil];
//    NSArray *data = [NSArray arrayWithArray:nodelArry];
//    NSLog(@"%ld",data.count);
    TreeTableView *tableview = [[TreeTableView alloc] initWithFrame:CGRectMake(0, 3, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)) withData:nodelArry];
    tableview.treeTableCellDelegate = self;
    tableview.backgroundColor = NewViewBack;
    [self.view addSubview:tableview];
//    [tableview reloadData];
}

//
//- (void)initTwoData {
//    NSMutableArray *nodelArry = [[NSMutableArray alloc]init];
//    for (int i = 0 ; i<self.twoArray.count; i++) {
//        NSLog(@"名字%@",self.twoArray[i]);
//        Node *gen1 = [[Node alloc] initWithParentId:i nodeId:10+i name:self.twoArray[i] depth:1 expand:NO];
//        [nodelArry addObject:gen1];
//    }
//    NSLog(@"nodel的个数%ld",nodelArry.count);
//
//    TreeTableView *tableview = [[TreeTableView alloc] initWithFrame:CGRectMake(0, 3, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)) withData:nodelArry];
//    tableview.treeTableCellDelegate = self;
//    tableview.backgroundColor = NewViewBack;
//    [self.view addSubview:tableview];
//    //    [tableview reloadData];
//}

- (void)cellClick:(Node *)node {
    NSLog(@"%@",node.name);
    if (node.depth == 0) {
        for (int i=0; i<self.datasArray.count; i++) {
            if (i==node.nodeId) {
                NSDictionary *dicUrl = self.datasArray[i];
                NSString *urls = dicUrl[@"contentUrl"];
                NSLog(@"%@",urls);
                UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
                CYLTabBarController *tbc = (CYLTabBarController *)keyWindow.rootViewController;
                QuestionSpaceController *qsc = (QuestionSpaceController *)tbc.viewControllers[1];
                
                QuestDetailController *detail = [[QuestDetailController alloc]init];
                detail.urls = urls;
                UINavigationController *detailNav = [[UINavigationController alloc]initWithRootViewController:detail];
                [qsc presentViewController:detailNav animated:YES completion:nil];
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

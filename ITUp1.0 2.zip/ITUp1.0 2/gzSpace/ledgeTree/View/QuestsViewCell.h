//
//  QuestsViewCell.h
//  gzSpace
//
//  Created by PAAT on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QuestsViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *logoImg;
@property (weak, nonatomic) IBOutlet UILabel *title;
@end

NS_ASSUME_NONNULL_END

//
//  QuestionSpaceController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/10/14.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "QuestionSpaceController.h"
#import "NBLScrollTabController.h"
#import "LedgeThreeController.h"

@interface QuestionSpaceController ()<NBLScrollTabControllerDelegate>
@property (nonatomic, strong) NBLScrollTabController *scrollTabController;
@property (nonatomic, strong) NSMutableArray *viewControllers;
@property (nonatomic, strong) NSMutableArray *datasArray;
@end

@implementation QuestionSpaceController

//- (void)viewWillAppear:(BOOL)animated {
//    [super viewWillAppear:YES];
//    [self loadData];
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"面试题库";
    self.datasArray = [NSMutableArray new];
//    NSArray *dataArray = @[@"Object_C基础",@"UI控件基础",@"性能优化",@"网络请求",@"Runtime",@"项目相关"];
//    self.datasArray = [NSMutableArray arrayWithArray:dataArray];
    [self loadData];
}

- (void)loadData {
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"qs/questTypeList/"];
    NSLog(@"请求地址%@",urls);
    [CYXHttpRequest get:urls params:nil success:^(id responseObj) {
        NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
        [self.datasArray removeAllObjects];
        for (NSDictionary *dic in dataArray) {
           
            [self.datasArray addObject:dic[@"title"]];
        }
        NSLog(@"%@",self.datasArray);
        [self.view addSubview:self.scrollTabController.view];
        //        [self.tableView reloadData];
    } failure:^(NSError *error) {
    }];
}

- (NBLScrollTabController *)scrollTabController {
    if (!_scrollTabController) {
        _scrollTabController = [[NBLScrollTabController alloc] init];
        _scrollTabController.view.frame =  CGRectMake(0, 0, WIDTH, HEIGHT);
        //        _scrollTabController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _scrollTabController.delegate = self;
        _scrollTabController.viewControllers = self.viewControllers;
    }
    return _scrollTabController;
}

- (NSArray *)viewControllers {
    if (!_viewControllers) {
        NSMutableArray *data = [[NSMutableArray alloc]init];
        for (int i=0; i<self.datasArray.count; i++) {
            LedgeThreeController *demo0 = [[LedgeThreeController alloc] init];
            demo0.typeOne = self.datasArray[i];
            demo0.view.backgroundColor = [UIColor clearColor];
            NBLScrollTabItem *demo0Item = [[NBLScrollTabItem alloc] init];
            demo0Item.title = self.datasArray[i];
            
            demo0Item.textColor = [UIColor darkGrayColor];
            demo0Item.highlightColor = OneColor;
            demo0Item.hideBadge = YES;//每个title可以做个性化配置
            demo0.tabItem = demo0Item;
            [data addObject:demo0];
        }
        _viewControllers = data;
    }
    return _viewControllers;
}

- (void)tabController:(NBLScrollTabController * __nonnull)tabController didSelectViewController:( UIViewController * __nonnull)viewController {
    NSLog(@"标题%@",viewController.tabItem.title);

//    LedgeThreeController *demo0 = (LedgeThreeController *)viewController;
//    demo0.typeOne = viewController.tabItem.title;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}

@end

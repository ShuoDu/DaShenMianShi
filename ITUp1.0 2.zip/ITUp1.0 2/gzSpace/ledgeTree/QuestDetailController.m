//
//  QuestDetailController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/10/16.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "QuestDetailController.h"
#import "QuestDetailController.h"
@interface QuestDetailController ()
@property (nonatomic,strong)UIWebView *webView;
@end

@implementation QuestDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"问题详情";
    
    UIButton *leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, 25, 25)];
    leftBtn.centerY = self.navigationController.navigationBar.centerY;
    [leftBtn setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationController.navigationBar addSubview:leftBtn];
    
    self.webView = [[UIWebView alloc]init];
    self.webView.frame = [UIScreen mainScreen].bounds;
    NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:self.urls]];
    [self.webView loadRequest:request];
    [self.view addSubview:self.webView];
}

- (void)backAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

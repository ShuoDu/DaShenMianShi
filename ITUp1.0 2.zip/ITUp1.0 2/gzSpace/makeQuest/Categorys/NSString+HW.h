//
//  NSString+HW.h
//  HWExercises
//
//  Created by sxmaps_w on 2017/5/22.
//  Copyright © 2017年 wqb. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HW)

//MD5加密
- (NSString *)MD5;

@end

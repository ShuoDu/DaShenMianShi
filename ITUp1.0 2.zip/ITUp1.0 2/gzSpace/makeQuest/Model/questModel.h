//
//  questModel.h
//  gzSpace
//
//  Created by 杜硕 on 2018/11/5.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface questModel : NSObject
@property (nonatomic,strong)NSString *title;
@property (nonatomic,strong)NSString *time;
@property (nonatomic,strong)NSString *quest_img;
@end

//
//  questionDetail.h
//  gzSpace
//
//  Created by PAAT on 2018/11/22.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface questionDetail : NSObject<YYModel>
@property (nonatomic,strong)NSString *totalCount;
@property (nonatomic,strong)NSString *question;
@property (nonatomic,strong)NSString *questiontype;
@property (nonatomic,strong)NSString *questiontype_text;
@property (nonatomic,strong)NSString *questionselectnumber;
@property (nonatomic,strong)NSString *questiondescribe;
@property (nonatomic,strong)NSString *trueanswer;
@property (nonatomic,strong)NSString *userAnswer;
@property (nonatomic,strong)NSArray *tkselect; 

@end

NS_ASSUME_NONNULL_END

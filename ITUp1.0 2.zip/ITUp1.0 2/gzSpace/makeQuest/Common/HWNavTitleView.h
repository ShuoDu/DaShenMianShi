//
//  HWNavTitleView.h
//  HWExercises
//
//  Created by sxmaps_w on 2017/5/22.
//  Copyright © 2017年 wqb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HWNavTitleView : UIView

- (id)initWithString:(NSString *)str frame:(CGRect)frame;

@end

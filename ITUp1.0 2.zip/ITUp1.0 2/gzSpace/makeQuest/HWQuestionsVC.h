//
//  HWQuestionsVC.h
//  HWExercises
//
//  Created by sxmaps_w on 2017/6/1.
//  Copyright © 2017年 wqb. All rights reserved.
//

#import "BaseController.h"

@interface HWQuestionsVC : BaseController
@property (nonatomic,strong)NSString *gather;
@end

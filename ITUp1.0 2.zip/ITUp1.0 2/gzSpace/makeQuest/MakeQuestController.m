//
//  MakeQuestController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/22.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "MakeQuestController.h"
#import "MainOneCell.h"
#import "MakeQuestTableViewCell.h"
#import "HWQuestionsVC.h"
#import "MainModel.h"
#import "questModel.h"
static NSString *oneCell = @"MakeQuestTableViewCell";

@interface MakeQuestController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *myTable;
@property(nonatomic,strong)NSMutableArray *dataArray;
@end

@implementation MakeQuestController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"做题";
    [self addConfigView];
    self.dataArray = [[NSMutableArray alloc]init];
    [self.myTable registerNib:[UINib nibWithNibName:@"MakeQuestTableViewCell" bundle:nil] forCellReuseIdentifier:oneCell];
    [self loadData];
}

- (void)loadData {
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"mq/questionList/"];
    NSLog(@"请求地址%@",urls);
    [CYXHttpRequest get:urls params:nil success:^(id responseObj) {
        
        NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
        
        for (NSDictionary *dict in dataArray) {
            questModel *newsModel = [questModel yy_modelWithDictionary:dict];
            [self.dataArray addObject:newsModel];
        }
        
        [self.myTable reloadData];
        
    } failure:^(NSError *error) {
    }];
}

- (void)addConfigView {
    self.myTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT-80)];
    self.myTable.backgroundColor = NewViewBack;
    self.myTable.dataSource = self;
    self.myTable.delegate = self;
    self.myTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.myTable];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 130;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    questModel *model = self.dataArray[indexPath.row];
    MakeQuestTableViewCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"MakeQuestTableViewCell"];
    [cellOne loadData:model];
    cellOne.backgroundColor = [UIColor clearColor];
    cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
    cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
    return cellOne;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    questModel *model = self.dataArray[indexPath.row];
    HWQuestionsVC *quest = [[HWQuestionsVC alloc]init];
    quest.hidesBottomBarWhenPushed = YES;
    quest.gather = model.title;
    [self.navigationController pushViewController:quest animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end

//
//  AppDelegate.m
//  gzSpace
//
//  Created by 智享单车 on 2017/12/11.
//  Copyright © 2017年 智享单车. All rights reserved.
//

#import "AppDelegate.h"
#import "LeftSideViewController.h"
#import "LaGouController.h"
#import "TableHeaderAnimationVC.h"
#import "LedgeThreeController.h"
#import "QuestBankController.h"
#import "MakeQuestController.h"
#import "InterViewController.h"
#import "CYLTabBarController.h"
#import "TableHeaderAnimationVC.h"
#import "QuestionSpaceController.h"


@interface AppDelegate ()<UITabBarControllerDelegate, IIViewDeckControllerDelegate>
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    //大神进阶，大牛面试
    [self setupViewControllers];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

    return YES;
}

- (void)setupViewControllers {
    
    LaGouController *lagou = [[LaGouController alloc]init];
    UINavigationController * lagouNc = [[UINavigationController alloc]initWithRootViewController:lagou];
    UINavigationController * ledgeNc = [[UINavigationController alloc]initWithRootViewController:[QuestionSpaceController new]];
    UINavigationController * queastNc = [[UINavigationController alloc]initWithRootViewController:[QuestBankController new]];
    
    UINavigationController * makeQuestNc = [[UINavigationController alloc]initWithRootViewController:[MakeQuestController new]];
    UINavigationController * interViewNc = [[UINavigationController alloc]initWithRootViewController:[InterViewController new]];
    UINavigationController * meNc = [[UINavigationController alloc]initWithRootViewController:[LedgeThreeController new]];
    
    UINavigationController *leftNvi=[[UINavigationController alloc]initWithRootViewController:[TableHeaderAnimationVC new]];
    
    CYLTabBarController *tbc = [CYLTabBarController new];
    [self customTabBarForController:tbc];
    [tbc setViewControllers:@[lagouNc,ledgeNc,makeQuestNc,leftNvi]];
    self.tabBarController = tbc;
    self.window.rootViewController = tbc;
}

- (void)customTabBarForController:(CYLTabBarController *)tbc {
    NSDictionary *dict0 = @{CYLTabBarItemTitle:@"首页",
                            CYLTabBarItemImage:@"news",
                            CYLTabBarItemSelectedImage:@"newsblue"};
    NSDictionary *dict1 = @{CYLTabBarItemTitle:@"题库",
                            CYLTabBarItemImage:@"live",
                            CYLTabBarItemSelectedImage:@"liveblue"};
    NSDictionary *dict2 = @{CYLTabBarItemTitle:@"做题",
                            CYLTabBarItemImage:@"market",
                            CYLTabBarItemSelectedImage:@"marketblue"};
    NSDictionary *dict3 = @{CYLTabBarItemTitle:@"我的",
                            CYLTabBarItemImage:@"my",
                            CYLTabBarItemSelectedImage:@"myblue"};
    NSArray *tabBarItemsAttributes = @[dict0,dict1,dict2,dict3];
    tbc.tabBarItemsAttributes = tabBarItemsAttributes;
}

- (UIWindow *)window {
    if(_window == nil) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

- (UITabBarController *)tabBarController {
    if(_tabBarController == nil) {
        _tabBarController = [[UITabBarController alloc] init];
    }
    return _tabBarController;
}


- (void)applicationWillResignActive:(UIApplication *)application {

}

- (void)applicationDidEnterBackground:(UIApplication *)application {

}

- (void)applicationWillEnterForeground:(UIApplication *)application {

}

- (void)applicationDidBecomeActive:(UIApplication *)application {

}

- (void)applicationWillTerminate:(UIApplication *)application {
  
}


@end

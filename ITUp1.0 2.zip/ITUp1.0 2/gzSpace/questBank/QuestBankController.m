//
//  QuestBankController.m
//  gzSpace
//
//  Created by 杜硕 on 2018/9/22.
//  Copyright © 2018年 智享单车. All rights reserved.
//

#import "QuestBankController.h"
#import "MainOneCell.h"

static NSString *oneCell = @"MainOneCell";
@interface QuestBankController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *myTable;
@end

@implementation QuestBankController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"题库";
    [self addConfigView];
    [self.myTable registerNib:[UINib nibWithNibName:@"MainOneCell" bundle:nil] forCellReuseIdentifier:oneCell];
    [self loadData];
}

- (void)loadData {
    NSString *urls = [NSString stringWithFormat:@"%@%@",Host,@"qs/questTypeOneList/"];
    NSLog(@"请求地址%@",urls);
    [CYXHttpRequest get:urls params:nil success:^(id responseObj) {
    
        NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:responseObj options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"数据%@",dict);
       
//        [self.tableView reloadData];
        
    } failure:^(NSError *error) {
    }];
}

- (void)addConfigView {
    self.myTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
//    self.myTable.backgroundColor = NewViewBack;
    self.myTable.backgroundColor = [UIColor colorWithRed:235/255.0
                                                green:240/255.0
                                                 blue:240/255.0
                                                alpha:1.0];
    self.myTable.dataSource = self;
    self.myTable.delegate = self;
    self.myTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.myTable];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 95;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MainOneCell *cellOne = [tableView dequeueReusableCellWithIdentifier:@"MainOneCell"];
    cellOne.backgroundColor = [UIColor clearColor];
    cellOne.layoutMargins = UIEdgeInsetsMake(0, 0, 0, 0);
    cellOne.selectionStyle = UITableViewCellSelectionStyleNone;
    cellOne.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cellOne;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}


@end
